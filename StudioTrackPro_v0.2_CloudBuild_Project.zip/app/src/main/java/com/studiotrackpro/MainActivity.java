package com.studiotrackpro;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.midi.*;
import android.os.Handler;
import android.os.Looper;
import java.util.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(13,20,31), PANEL=Color.rgb(25,37,53), GOLD=0xffffc247, WHITE=Color.WHITE;
    private LinearLayout root, padGrid, presetRow, layersBox;
    private TextView status, currentPreset;
    private Synth synth;
    private MidiManager midiManager;
    private MidiDevice midiDevice;
    private MidiInputPort midiInput;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final String[] padNames={"Warm Pad","Air Choir","Soft Drone","Piano Tone"};
    private final int[] padColors={0xff2479e8,0xff8b5cf6,0xff0f9f88,0xffd97706};
    private final boolean[] padOn={false,false,false,false};
    private int rootNote=60;
    private String preset="Sunday Worship";
    private float masterVolume=0.55f;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        synth=new Synth();
        buildUi();
        updatePadButtons();
        refreshStatus("Ready. Tap a pad to start/stop its original synthesized tone.");
        checkMidi();
    }
    private TextView label(String s,int size,int color) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(8,7,8,7); return t;
    }
    private Button btn(String s) {
        Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(PANEL)); return b;
    }
    private LinearLayout column() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private void buildUi() {
        ScrollView sc=new ScrollView(this);
        root=column(); root.setPadding(12,12,12,16); root.setBackgroundColor(BG);
        TextView title=label("StudioTrack Pro",27,WHITE); title.setTypeface(null,Typeface.BOLD); root.addView(title);
        root.addView(label("WORSHIP PADS  •  STAGE CONTROL  •  v0.2",12,GOLD));
        status=label("Starting audio engine…",13,0xffd2d9e4); status.setBackgroundColor(PANEL); root.addView(status);
        root.addView(label("LIVE PAD PLAYER",16,GOLD));
        padGrid=new LinearLayout(this); padGrid.setOrientation(LinearLayout.VERTICAL); root.addView(padGrid);
        root.addView(label("STAGE PRESETS",16,GOLD));
        presetRow=new LinearLayout(this); presetRow.setOrientation(LinearLayout.VERTICAL); root.addView(presetRow);
        currentPreset=label("Current setup: "+preset,14,WHITE); currentPreset.setBackgroundColor(PANEL); root.addView(currentPreset);
        root.addView(label("KEY / TRANSPOSITION",16,GOLD));
        LinearLayout keys=new LinearLayout(this);
        Button down=btn("− Semitone"); down.setOnClickListener(v->{rootNote=Math.max(36,rootNote-1); synth.setRoot(rootNote); updateKeyLabel(keys);});
        Button up=btn("+ Semitone"); up.setOnClickListener(v->{rootNote=Math.min(84,rootNote+1); synth.setRoot(rootNote); updateKeyLabel(keys);});
        keys.addView(down,new LinearLayout.LayoutParams(0,-2,1)); keys.addView(up,new LinearLayout.LayoutParams(0,-2,1)); root.addView(keys);
        updateKeyLabel(root);
        root.addView(label("MASTER LEVEL",16,GOLD));
        SeekBar master=new SeekBar(this); master.setMax(100); master.setProgress(55);
        master.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean u){masterVolume=p/100f;synth.setMaster(masterVolume);}
            public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
        }); root.addView(master);
        root.addView(label("MIDI KEYBOARD",16,GOLD));
        LinearLayout mr=new LinearLayout(this);
        Button refresh=btn("Refresh MIDI"); refresh.setOnClickListener(v->checkMidi());
        Button connect=btn("Connect first device"); connect.setOnClickListener(v->connectFirstMidi());
        mr.addView(refresh,new LinearLayout.LayoutParams(0,-2,1)); mr.addView(connect,new LinearLayout.LayoutParams(0,-2,1)); root.addView(mr);
        root.addView(label("Stage 0.2 uses original synthesized tones. Sampled piano/pad soundfonts, MIDI instrument rendering, multitrack recording and project saving are future stages.",12,0xff9aa8bb));
        sc.addView(root); setContentView(sc);
        buildPads(); buildPresets();
    }
    private void updateKeyLabel(LinearLayout ignored) {
        // Keep status concise while transposing the running tones.
        if(status!=null) status.setText("Key shift: "+(rootNote-60)+" semitones  •  "+(midiDevice==null?"MIDI not connected":"MIDI connected"));
    }
    private void buildPads() {
        padGrid.removeAllViews();
        for(int i=0;i<padNames.length;i+=2) {
            LinearLayout row=new LinearLayout(this);
            for(int j=i;j<Math.min(i+2,padNames.length);j++) {
                final int idx=j;
                Button b=btn(padNames[j]+"\n"+(padOn[j]?"PLAYING":"Tap to play"));
                b.setMinHeight(100);
                b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(padOn[j]?padColors[j]:PANEL));
                b.setOnClickListener(v->togglePad(idx));
                row.addView(b,new LinearLayout.LayoutParams(0,-1,1));
            }
            padGrid.addView(row);
        }
    }
    private void updatePadButtons(){ if(padGrid!=null) buildPads(); }
    private void togglePad(int i) {
        padOn[i]=!padOn[i];
        if(padOn[i]) synth.startPad(i); else synth.stopPad(i);
        updatePadButtons();
        refreshStatus(padNames[i]+(padOn[i]?" started.":" stopped."));
    }
    private void buildPresets() {
        presetRow.removeAllViews();
        String[] names={"Sunday Worship","Quiet Prayer","Big Chorus","Ambient Drone"};
        for(String n:names) {
            Button b=btn("▶  "+n);
            b.setOnClickListener(v->applyPreset(n));
            presetRow.addView(b);
        }
    }
    private void applyPreset(String p) {
        preset=p;
        Arrays.fill(padOn,false);
        synth.stopAll();
        if(p.equals("Sunday Worship")) {padOn[0]=true;padOn[1]=true;}
        else if(p.equals("Quiet Prayer")) {padOn[1]=true;}
        else if(p.equals("Big Chorus")) {padOn[0]=true;padOn[1]=true;padOn[2]=true;}
        else {padOn[2]=true;}
        for(int i=0;i<padOn.length;i++) if(padOn[i]) synth.startPad(i);
        currentPreset.setText("Current setup: "+p);
        updatePadButtons(); refreshStatus("Preset loaded: "+p);
    }
    private void checkMidi() {
        if(android.os.Build.VERSION.SDK_INT<23){refreshStatus("Android MIDI API unavailable.");return;}
        midiManager=(MidiManager)getSystemService(Context.MIDI_SERVICE);
        if(midiManager==null){refreshStatus("MIDI service unavailable on this device.");return;}
        MidiDeviceInfo[] ds=midiManager.getDevices();
        StringBuilder s=new StringBuilder("MIDI devices detected: ").append(ds.length);
        for(MidiDeviceInfo d:ds) {
            String n=d.getProperties().getString(MidiDeviceInfo.PROPERTY_NAME);
            s.append("\n• ").append(n==null?"USB MIDI device":n);
        }
        if(ds.length==0)s.append("\nCheck OTG adapter, keyboard USB MIDI mode and USB permission.");
        refreshStatus(s.toString());
    }
    private void connectFirstMidi() {
        if(midiManager==null) midiManager=(MidiManager)getSystemService(Context.MIDI_SERVICE);
        if(midiManager==null){refreshStatus("MIDI service unavailable.");return;}
        MidiDeviceInfo[] ds=midiManager.getDevices();
        if(ds.length==0){refreshStatus("No MIDI device found. Connect the keyboard via USB OTG and refresh.");return;}
        midiManager.openDevice(ds[0], device -> {
            if(device==null){refreshStatus("Could not open MIDI device.");return;}
            midiDevice=device;
            MidiDeviceInfo.PortInfo[] ports=device.getInfo().getPorts();
            for(MidiDeviceInfo.PortInfo port:ports) {
                if(port.getType()==MidiDeviceInfo.PortInfo.TYPE_OUTPUT) {
                    try {
                        midiInput=device.openInputPort(port.getPortNumber());
                        if(midiInput!=null) midiInput.connect(new MidiReceiver(){
                            @Override public void onSend(byte[] data,int offset,int count,long timestamp) {
                                for(int k=offset;k<offset+count;k+=3) {
                                    if(k+2>=offset+count) break;
                                    int cmd=data[k]&0xf0, note=data[k+1]&0x7f, vel=data[k+2]&0x7f;
                                    if(cmd==0x90 && vel>0) synth.noteOn(note,vel/127f);
                                    else if(cmd==0x80 || (cmd==0x90 && vel==0)) synth.noteOff(note);
                                }
                            }
                        });
                    } catch(Exception e){refreshStatus("MIDI port error: "+e.getMessage());}
                }
            }
            refreshStatus("Connected to "+ds[0].getProperties().getString(MidiDeviceInfo.PROPERTY_NAME)+". MIDI notes trigger the built-in tone engine.");
        },mainHandler);
    }
    private void refreshStatus(String s){ if(status!=null) status.setText(s); }
    private void updateKeyLabel(View v){}

    @Override protected void onDestroy() {
        if(synth!=null)synth.close();
        try{if(midiInput!=null)midiInput.close();}catch(Exception e){}
        try{if(midiDevice!=null)midiDevice.close();}catch(Exception e){}
        super.onDestroy();
    }

    // Small original real-time tone engine. This is a prototype synthesizer, not a sampled soundfont engine.
    private static class Synth {
        private final int sr=22050;
        private AudioTrack track;
        private Thread thread;
        private volatile boolean running=true;
        private final Object lock=new Object();
        private final Map<Integer,Float> notes=new HashMap<>();
        private final boolean[] pads=new boolean[4];
        private volatile int root=60;
        private volatile float master=.55f;
        private double phase=0;
        Synth() {
            int min=AudioTrack.getMinBufferSize(sr,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT);
            track=new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(new AudioFormat.Builder().setSampleRate(sr).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()).setBufferSizeInBytes(Math.max(min,sr/2))
                .setTransferMode(AudioTrack.MODE_STREAM).build();
            track.play();
            thread=new Thread(()->render(),"StudioTrack-Audio");thread.start();
        }
        void setRoot(int n){root=n;}
        void setMaster(float v){master=v;}
        void startPad(int i){synchronized(lock){pads[i]=true;}}
        void stopPad(int i){synchronized(lock){pads[i]=false;}}
        void stopAll(){synchronized(lock){Arrays.fill(pads,false);notes.clear();}}
        void noteOn(int n,float vel){synchronized(lock){notes.put(n,vel);}}
        void noteOff(int n){synchronized(lock){notes.remove(n);}}
        private void render(){
            short[] buf=new short[512];
            while(running) {
                for(int i=0;i<buf.length;i++) {
                    double mix=0; int count=0;
                    synchronized(lock) {
                        for(Map.Entry<Integer,Float> e:notes.entrySet()) {
                            double f=440.0*Math.pow(2,(e.getKey()-69)/12.0);
                            mix+=Math.sin(phase*f*2*Math.PI/sr)*e.getValue();count++;
                        }
                        for(int p=0;p<pads.length;p++) if(pads[p]) {
                            int n=root + (p==1?7:(p==2?-12:(p==3?12:0)));
                            double f=110.0*Math.pow(2,(n-45)/12.0);
                            double wave=Math.sin(phase*f*2*Math.PI/sr);
                            if(p==0) wave=(wave+0.35*Math.sin(phase*f*4*Math.PI/sr))/1.35;
                            if(p==1) wave=(wave+Math.sin(phase*f*1.003*2*Math.PI/sr)*0.6)/1.6;
                            if(p==2) wave=Math.sin(phase*f*2*Math.PI/sr)*0.7;
                            mix+=wave*0.22;count++;
                        }
                    }
                    phase+=1;
                    double val=count==0?0:mix/Math.max(1,Math.sqrt(count))*master;
                    buf[i]=(short)(Math.max(-1,Math.min(1,val))*24000);
                }
                if(track!=null) track.write(buf,0,buf.length);
            }
        }
        void close(){running=false;try{if(thread!=null)thread.join(300);}catch(Exception e){} try{track.pause();track.flush();track.release();}catch(Exception e){}}
    }
}
