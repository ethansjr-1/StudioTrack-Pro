# StudioTrack Pro v0.2 — worship pad + stage prototype

## Implemented in this source version
- Touchscreen pad buttons: Warm Pad, Air Choir, Soft Drone, Piano Tone
- Original synthesized tones generated locally (not copied or sampled from another app)
- Four stage presets: Sunday Worship, Quiet Prayer, Big Chorus, Ambient Drone
- Semitone up/down control and master level slider
- Android MIDI device enumeration and attempt to connect to first MIDI output port
- Basic MIDI note-on/note-off tone triggering

## Known prototype limitations
- This is not a polished or tested audio engine. It uses simple sine-based tones, not high-quality sampled piano/pad sounds.
- MIDI port behavior varies by device and keyboard. It must be tested on physical hardware.
- Pad sounds are synthesized tones and do not yet include a soundfont/sample import browser.
- No project saving, multitrack audio recording/playback, audio effects, or export/mixdown yet.
- This is Android source code, not a compiled APK.

## Build
Open this folder in Android Studio with JDK 17 and Android SDK 35. Sync Gradle, then use Build > Build APK(s). Install the debug APK on a test phone. Check audio output and MIDI connection with your Yamaha keyboard.

## Phone-only cloud build option
A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`.
To use it, create a GitHub repository, upload/extract the project files into it, then open the Actions tab and run **Build Android APK**. When it succeeds, download the `StudioTrack-Pro-debug-apk` artifact and extract `app-debug.apk` on your phone.
This requires a GitHub account and internet access. The workflow has not been run in this environment, so the build result is not guaranteed until GitHub completes it successfully.
